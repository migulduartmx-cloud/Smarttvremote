package br.smartremote

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Window
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import okhttp3.*
import org.json.JSONObject
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.*

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val sockets = ConcurrentHashMap<Int, WebSocket>()

    // A TV Samsung usa certificado autoassinado, então este cliente aceita o certificado dela.
    private val client: OkHttpClient by lazy {
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(c: Array<X509Certificate>, a: String) {}
            override fun checkServerTrusted(c: Array<X509Certificate>, a: String) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(tm), SecureRandom()) }
        OkHttpClient.Builder()
            .sslSocketFactory(ctx.socketFactory, tm)
            .hostnameVerifier { _, _ -> true }
            .build()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.statusBarColor = Color.parseColor("#14161c")
        window.navigationBarColor = Color.parseColor("#14161c")
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#14161c"))
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            @Suppress("DEPRECATION") allowUniversalAccessFromFileURLs = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun emit(id: Int, ev: String, data: String = "") = runOnUiThread {
        web.evaluateJavascript("window.__ws($id,'$ev',${JSONObject.quote(data)})", null)
    }

    inner class Bridge {
        @JavascriptInterface fun wsOpen(id: Int, url: String) {
            val req = Request.Builder().url(url).build()
            sockets[id] = client.newWebSocket(req, object : WebSocketListener() {
                override fun onOpen(ws: WebSocket, response: Response) = emit(id, "open")
                override fun onMessage(ws: WebSocket, text: String) = emit(id, "message", text)
                override fun onClosed(ws: WebSocket, code: Int, reason: String) { sockets.remove(id); emit(id, "close") }
                override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                    sockets.remove(id); emit(id, "error"); emit(id, "close")
                }
            })
        }
        @JavascriptInterface fun wsSend(id: Int, text: String) { sockets[id]?.send(text) }
        @JavascriptInterface fun wsClose(id: Int) { sockets[id]?.close(1000, null) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    override fun onDestroy() { sockets.values.forEach { it.cancel() }; super.onDestroy() }
}
